# microsoft-learning-paths-databricks-notebooks
Contains notebooks used in the Microsoft Azure Databricks Learning Paths modules.
